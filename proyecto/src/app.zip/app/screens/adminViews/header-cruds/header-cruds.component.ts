import { Component } from '@angular/core';

@Component({
  selector: 'app-header-cruds',
  templateUrl: './header-cruds.component.html',
  styleUrls: ['./header-cruds.component.css']
})
export class HeaderCrudsComponent {

}
