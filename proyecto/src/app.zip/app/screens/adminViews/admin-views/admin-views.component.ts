import { Component } from '@angular/core';

@Component({
  selector: 'app-admin-views',
  templateUrl: './admin-views.component.html',
  styleUrls: ['./admin-views.component.css']
})
export class AdminViewsComponent {

}
