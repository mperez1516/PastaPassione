import { Component } from '@angular/core';

@Component({
  selector: 'app-front-pages',
  templateUrl: './front-pages.component.html',
  styleUrls: ['./front-pages.component.css']
})
export class FrontPagesComponent {

}
