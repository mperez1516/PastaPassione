import { Component } from '@angular/core';

@Component({
  selector: 'app-home-admin-page',
  templateUrl: './home-admin-page.component.html',
  styleUrls: ['./home-admin-page.component.css']
})
export class HomeAdminPageComponent {

}
