import { Component } from '@angular/core';

@Component({
  selector: 'app-home-cliente-page',
  templateUrl: './home-cliente-page.component.html',
  styleUrls: ['./home-cliente-page.component.css']
})
export class HomeClientePageComponent {

}
