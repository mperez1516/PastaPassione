export interface Operador {
    idOperador: number;
    nombre: string;
    usuario: string;
    contrasena: string;
  }