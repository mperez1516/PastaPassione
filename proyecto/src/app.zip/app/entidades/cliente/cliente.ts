export interface Cliente {
    id?: number;
    nombre: string;
    apellido: string;
    correo: string;
    contrasena: string;
    telefono: number;
    direccion: number;
  }