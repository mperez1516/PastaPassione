export interface Administrador {
    id: number;
    nombre: string;
    apellido: string;
    usuario: string;
    contrasena: string;
  }