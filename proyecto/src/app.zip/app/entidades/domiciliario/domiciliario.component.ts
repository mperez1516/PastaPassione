import { Component } from '@angular/core';

@Component({
  selector: 'app-domiciliario',
  templateUrl: './domiciliario.component.html',
  styleUrls: ['./domiciliario.component.css']
})
export class DomiciliarioComponent {

}
