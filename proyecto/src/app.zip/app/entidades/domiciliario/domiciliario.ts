export interface Domiciliario {
    id: number;
    nombre: string;
    celular: number;
    disponibilidad: boolean;
  }