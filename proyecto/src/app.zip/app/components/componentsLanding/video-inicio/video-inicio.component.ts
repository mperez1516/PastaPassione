import { Component } from '@angular/core';

@Component({
  selector: 'app-video-inicio',
  templateUrl: './video-inicio.component.html',
  styleUrls: ['./video-inicio.component.css']
})
export class VideoInicioComponent {

}
